<?php namespace Illuminate\Encryption;

class DecryptException extends \RuntimeException {}
