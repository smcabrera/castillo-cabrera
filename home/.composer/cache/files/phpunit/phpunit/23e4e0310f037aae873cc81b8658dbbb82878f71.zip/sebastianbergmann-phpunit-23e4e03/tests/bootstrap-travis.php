<?php

ini_set('precision', 14);
ini_set('serialize_precision', 14);
