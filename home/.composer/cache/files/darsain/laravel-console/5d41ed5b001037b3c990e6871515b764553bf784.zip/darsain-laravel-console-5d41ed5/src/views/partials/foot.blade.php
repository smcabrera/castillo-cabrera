		{{ HTML::script('packages/darsain/laravel-console/js/vendor/jquery.js') }}
		{{ HTML::script('packages/darsain/laravel-console/js/vendor/plugins.js') }}
		{{ HTML::script('packages/darsain/laravel-console/js/vendor/codemirror.js') }}
		{{ HTML::script('packages/darsain/laravel-console/js/main.js') }}
	</body>
</html>