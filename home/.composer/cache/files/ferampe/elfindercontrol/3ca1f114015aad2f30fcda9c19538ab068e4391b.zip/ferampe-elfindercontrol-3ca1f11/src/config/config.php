<?php

return array(

    /**
     * Put the name of the folder where the files were stored, 
     * relative to folder public your project
     * 
     */
    'folder_path' => 'files',


    'lang' => 'es',

    /**
     * Hidden folder start dot (.)
     */

    'access' => 'Ferampe\Elfindercontrol\Elfindercontrol::access',

    /**
     * Custom option
     */
    'roots' => array()


);
