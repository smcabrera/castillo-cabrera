<?php namespace Ferampe\Elfindercontrol\Facades;

use Illuminate\Support\Facades\Facade;

class Elfindercontrol extends Facade {

	protected static function getFacadeAccessor(){
		return 'elfindercontrol';
	}
}