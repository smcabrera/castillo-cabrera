<?php echo $tpl->slug("hello world!"); ?>

My name is <?php echo $tpl->escape($name) ?>
