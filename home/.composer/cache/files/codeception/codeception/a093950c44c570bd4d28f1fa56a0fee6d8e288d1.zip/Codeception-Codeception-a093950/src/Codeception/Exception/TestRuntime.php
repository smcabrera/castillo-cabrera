<?php
namespace Codeception\Exception;

class TestRuntime extends \RuntimeException
{

}
