# Platform

Patform is base classes for any kind of extensions that relies on Codeception's event system. You can create Group/Extension and connect them to any Codeception event. 

## Sample Extensions

There are 2 sample extensions you may try:

* RunFailed - for saving information of all failed tests into file, in order to run them afterwards
* SimpleOutput - alternative output formatter