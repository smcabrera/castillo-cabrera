<?php
namespace Codeception\TestCase\Interfaces;

interface Reported {

    /**
     * @return array
     */
    public function getReportFields();

}