<?php

namespace Codeception\TestCase;

use Codeception\Events;
use Codeception\Event\TestEvent;
use Codeception\Util\Annotation;

class Cest extends \Codeception\TestCase implements
    Interfaces\ScenarioDriven,
    Interfaces\Descriptive,
    Interfaces\Reported,
    Interfaces\Configurable
{
    use Shared\Actor;
    use Shared\Dependencies;
    use Shared\ScenarioPrint;

    protected $testClassInstance = null;
    protected $testMethod = null;

    public function __construct(array $data = array(), $dataName = '')
    {
        parent::__construct('testCodecept', $data, $dataName);
    }

    public function getName($withDataSet = TRUE)
    {
        return $this->testMethod;
    }

    public function preload()
    {
        $this->scenario->setFeature($this->getSpecFromMethod());
        $code = $this->getRawBody();
        $params = (new \ReflectionMethod($this->testClassInstance, $this->testMethod))->getParameters();
        $scenarioVar = isset($params[1]) ? $params[1]->getName() : null;
        $this->parser->parseFeature($code);
        $this->parser->parseScenarioOptions($code, $scenarioVar);
        $this->fire(Events::TEST_PARSED, new TestEvent($this));
    }

    public function getRawBody()
    {
        $method = new \ReflectionMethod($this->testClassInstance, $this->testMethod);
        $start_line = $method->getStartLine() - 1; // it's actually - 1, otherwise you wont get the function() block
        $end_line = $method->getEndLine();
        $source = file($method->getFileName());
        return implode("", array_slice($source, $start_line, $end_line - $start_line));
    }

    public function testCodecept()
    {
        $this->fire(Events::TEST_BEFORE, new TestEvent($this));

        $this->scenario->run();
        $I = $this->makeIObject();

        try {
            $this->executeBefore($this->testMethod, $I);
            $this->executeTestMethod($I);
            $this->executeAfter($this->testMethod, $I);
        } catch (\Exception $e) {
            // fails and errors are now handled by Codeception\PHPUnit\Listener
            throw $e;
        }

        $this->fire(Events::TEST_AFTER, new TestEvent($this));
    }

    protected function executeBefore($testMethod, $I)
    {
        if (method_exists($this->testClassInstance, '_before')) {
            $this->testClassInstance->_before($I);
        }

        if ($before = Annotation::forClass($this->testClassInstance)->method($testMethod)->fetch('before')) {
            $this->executeContextMethod($before, $I);
        }

    }

    protected function executeAfter($testMethod, $I)
    {
        if ($after = Annotation::forClass($this->testClassInstance)->method($testMethod)->fetch('after')) {
            $this->executeContextMethod($after, $I);
        }

        if (method_exists($this->testClassInstance, '_after')) {
            $this->testClassInstance->_after($I);
        }
    }

    protected function executeContextMethod($context, $I)
    {
        if (method_exists($this->testClassInstance, $context)) {
            $this->executeBefore($context, $I);
            $contextMethod = new \ReflectionMethod($this->testClassInstance, $context);
            $contextMethod->setAccessible(true);
            $contextMethod->invoke($this->testClassInstance, $I);
            $this->executeAfter($context, $I);
            return;
        }

        throw new \LogicException(
            "Method $context defined in annotation but does not exists in " . get_class($this->testClassInstance)
        );
    }

    protected function makeIObject()
    {
        $className = '\\' . $this->actor;
        $I = new $className($this->scenario);
        $spec = $this->getSpecFromMethod();

        if ($spec) {
            $I->wantTo($spec);
        }
        return $I;
    }

    protected function executeTestMethod($I)
    {
        $testMethodSignature = array($this->testClassInstance, $this->testMethod);
        if (! is_callable($testMethodSignature)) {
            throw new \Exception("Method {$this->testMethod} can't be found in tested class");
        }
        call_user_func($testMethodSignature, $I, $this->scenario);
    }

    public function getTestClass()
    {
        return $this->testClassInstance;
    }

    public function getTestMethod()
    {
        return $this->testMethod;
    }

    public function getSpecFromMethod()
    {
        $text = $this->testMethod;
        $text = preg_replace('/([A-Z]+)([A-Z][a-z])/', '\\1 \\2', $text);
        $text = preg_replace('/([a-z\d])([A-Z])/', '\\1 \\2', $text);
        $text = strtolower($text);
        return $text;
    }

    public function configActor($actor)
    {
        foreach (['actor', 'guy'] as $annotation) {
            $definedActor = Annotation::forMethod($this->testClassInstance, $this->testMethod)->fetch($annotation);
            if (!$definedActor) {
                $definedActor = Annotation::forClass($this->testClassInstance)->fetch($annotation);
            }
            if ($definedActor) {
                $this->actor = $definedActor;
                return $this;
            }
        }

        $this->actor = $actor;
        return $this;
    }

    public function configEnv($env)
    {
        $this->testClassInstance->env = $env;
        return $this;
    }

    public function getSignature()
    {
        return get_class($this->getTestClass()) . "::" . $this->getTestMethod();
    }

    public function getFileName()
    {
        return $this->testFile;
    }

    public function toString()
    {
        return $this->getFeature(). " (".$this->getSignature().")";
    }
    
    /**
     * @return array
     */
    public function getReportFields()
    {
        return [
            'file' => $this->getFileName(),
            'name' => $this->getTestMethod(),
            'class' => get_class($this->getTestClass()),
            'feature' => $this->getFeature()
        ];
    }

}
