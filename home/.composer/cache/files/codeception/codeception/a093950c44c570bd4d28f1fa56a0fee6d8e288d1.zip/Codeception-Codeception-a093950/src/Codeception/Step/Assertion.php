<?php
namespace Codeception\Step;
 
class Assertion extends \Codeception\Step {
}
