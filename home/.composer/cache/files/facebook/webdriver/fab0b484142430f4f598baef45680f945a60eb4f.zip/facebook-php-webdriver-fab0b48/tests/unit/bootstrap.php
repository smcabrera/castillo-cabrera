<?php

require_once __DIR__ . '/../../lib/__init__.php';
